public class Entry<K, V> {
  private K key;
  private V val;

  // --------------- Constructor --------------- //
  public Entry(K _key, V _val) {key = _key; val = _val;}

  // --------------- Getters and Setters --------------- //
  public K getKey() {return key;}
  public V getValue() {return val;}

  public void setKey(K _key) {key = _key;}
  public void setValue(V _val) {val = _val;}
}
