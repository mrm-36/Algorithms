public class Student {
  private String lastName;
  private String firstName;
  private String id;
  private double grade;
  private char letter;

  // ------------------ Constructors ------------------ //
  public Student(String ln, String fn, String _id, double g, char l){
    lastName = ln; firstName = fn; id = _id; grade = g; letter = l;
  }

  // ------------------ Getters and Setters ------------------ //
  public String getLast() {return lastName;}
  public String getFirst() {return firstName;}
  public String getID() {return id;}
  public double getGrade() {return grade;}
  public char getLetter() {return letter;}

  public void setLast(String ln) {lastName = ln;}
  public void setFirst(String fs) {firstName = fs;}
  public void setID(String _id) {id = _id;}
  public void setGrade(double g) {grade = g;}
  public void setLetter(char l) {letter = l;}

  // ------------------ Basic Function ------------------ //

}
