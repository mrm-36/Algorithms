import java.util.Comparator;

public class DefaultComparator<E> implements Comparator<E> {
  private int reverse = 1;

  public DefaultComparator() {}

  /**
   * if rev == 0, sort by ascending order
   * descending order otherwise
   * @param rev integer value specifying the order by which to sort the values
   */
  public DefaultComparator(int rev){
    reverse = (rev != 0 ? -1 : 1);
  }

  @SuppressWarnings({"unchecked"})
  public int compare(E a, E b) throws ClassCastException {
    return reverse * ((Comparable<E>) a).compareTo(b);
  }
}
