import java.util.Scanner;
import java.io.File;
import java.io.FileNotFoundException;
import java.nio.channels.FileLockInterruptionException;
import java.util.*;

/**
 * @author Miguel R. Merheb
 */

public class Ex2 {
  public static HeapPQ<String, Student> heap;
  public static int key;

  /**
   * Initializes a new heap with a custom comparator
   * @param k the key by which to sort the values
   * @param rev the order of the values (i.e. ascending or descending)
   */
  public static void init(int k, int rev){
    key = k;
    DefaultComparator<String> comp = new DefaultComparator<String>(rev);
    heap = new HeapPQ<String, Student>(comp);
  }
 
  /**
   * Reads the values from the Scanner
   * Creates a new Student object with the values
   * And inserts it in the heap with the correct key
   * @param cin Scanner from where to read the values
   */
  public static void read_file(Scanner cin){
    while (cin.hasNextLine()){
      Scanner line = new Scanner(cin.nextLine());
      List<String> x = new ArrayList<>();
      while (line.hasNext()) x.add(line.next());
      Student st = new Student(x.get(0), x.get(1), x.get(2), Double.parseDouble(x.get(3)), x.get(4).charAt(0));
      heap.insert(x.get(key), st);
    }
  }

  /**
   * Prints the student object based on a specific alignment
   * @param st student object
   */
  private static void print(Student st){
    System.out.printf(
      "%-10s %-10s %-10s %-7.1f %-5c\n", 
      st.getLast(), st.getFirst(), st.getID(), st.getGrade(), st.getLetter()
    );
  }

  /**
   * Displays the output
   * (i.e. Get the sorted values from the heap and print them)
   */
  public static void output(){
    for (Student x : heap.toArray()) print(x);
  }

  /**
   * Prompts the user to choose a key (Last Name, First Name, ID, Grade, Letter Grade)
   * And an order (Ascending, Descending)
   * Then calls the above "init" function
   * @param cin Scanner from where to read the input
   */
  public static void init(Scanner cin){
    System.out.println("Choose Key: ");
    System.out.println("  0 : Last Name\n  1 : First Name");
    System.out.println("  2 : Student ID\n  3 : Grade\n  4 : Letter Grade");
    int k = -1;
    while (k == -1){
      try {
        k = Integer.parseInt(cin.next());
        if (k < 0 || k > 4) throw new InputMismatchException("Invalid Choice");
      } 
      catch (Exception ex) {System.out.println(ex.getMessage() + "\n"); k = -1;}
    }

    System.out.println("\nChoose Order: ");
    System.out.println("  0 : Ascending\n  1 : Descending");
    int r = -1;
    while (r == -1){
      try {
        r = Integer.parseInt(cin.next());
        if (r != 0 && r != 1) throw new InputMismatchException("Invalid Choice");
      } 
      catch (Exception ex) {System.out.println(ex.getMessage() + "\n"); r = -1;}
    }
    System.out.println();
    init(k, r);
  }

  public static void main(String[] args) throws FileLockInterruptionException, FileNotFoundException{
    init(new Scanner(System.in));
    read_file(new Scanner(new File("student.dat")));
    output();
  }
}