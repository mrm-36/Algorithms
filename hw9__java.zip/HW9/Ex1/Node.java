public class Node {
  private long x;
  private Node left;
  private Node right;
  private Node parent;

  public Node(long _x, Node _parent, Node _left, Node _right){
    x = _x; parent = _parent; left = _left; right = _right;
  }
  public Node(long _x) {this(_x, null, null, null);}
  public Node(long _x, Node _parent){this(_x, _parent, null, null);}

  public long getX() {return x;}
  public Node getParent() {return parent;}
  public Node getLeft() {return left;}
  public Node getRight() {return right;}

  public void setX(long _x) {x = _x;}
  public void setParent(Node _parent) {parent = _parent;}
  public void setLeft(Node _left) {left = _left;}
  public void setRight(Node _right) {right = _right;}

  public int nbChildren() {
    return (left != null ? 1 : 0) + (right != null ? 1 : 0);
  }

  public boolean isLeaf() {return nbChildren() == 0;}
}
