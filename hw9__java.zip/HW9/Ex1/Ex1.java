import java.util.*;
import java.io.*;

/**
 * @author Miguel R. Merheb
 */

class BST_Tree extends BST {

  /**
   * Searches for the node that contains the value x 
   * while keeping track the total nb of comparaisons
   * @param x the value of the node we are searching for
   * @return {
   *          1 if we found the node and 0 otherwise,
   *          total nb of comparaisons
   *         }
   */
  public int[] FindAndCount(long x){
    Node curr = root(); int comp = 0;
    while (curr != null && curr.getX() != x){
      if (x < curr.getX()) curr = curr.getLeft();
      else curr = curr.getRight();
      ++comp;
    }
    int[] y = {(curr != null ? 1 : 0), comp};
    return y;
  }
}

public class Ex1 {
  public static BST_Tree tree = new BST_Tree(); 
  public static int nb_of_searches = 0;
  public static Map<Long, Integer> success = new HashMap<Long, Integer>();
  public static Map<Long, Integer> failure = new HashMap<Long, Integer>();

  /**
   * Read from the Scanner and add to the tree
   * @param cin Scanner from where to read the input
   */
  public static void read_file(Scanner cin){
    while (cin.hasNextInt()) tree.add(cin.nextInt()); 
  }

  /**
   * For each value read by the Scanner, call the "FindAndCount" function
   * and store it's result accordingly
   * @param cin Scanner from where to read the input
   */
  public static void FindAll(Scanner cin){
    while (cin.hasNextInt()){
      ++nb_of_searches; long x = cin.nextInt();
      int[] res = tree.FindAndCount(x);
      if (res[0] == 1) success.put(x, res[1]);
      else failure.put(x, res[1]);
    }
  }

  /**
   * Displays the input in a table
   * @param mp the (key, value) pairs that we want to display
   */
  public static void print(Map<Long, Integer> mp){
    Iterator<Map.Entry<Long, Integer>> itr = mp.entrySet().iterator();
    String hline = "  ------------------------------";
    System.out.println(hline);
	  System.out.printf("  |%8s    | %10s |\n", "Value", "#Comparaisons");
    System.out.println(hline);
    while (itr.hasNext()) {
      Map.Entry<Long, Integer> e = itr.next();
	    System.out.printf("  |%10d  | %8d      |\n", e.getKey(), e.getValue());
      System.out.println(hline);
	  }
  }

  /**
   * Writes the output to the specified PrintStream
   * - Adds a table output if tbl was TRUE
   * @param out PrintStream where to output the results
   * @param tbl if True, display a table containing the detailed results, do nothing otherwise
   */
  public static void write_output(PrintStream out, boolean tbl){
    System.setOut(out);

    System.out.println("Tree Size = " + tree.size());
    System.out.println("Tree Height = " + tree.height() + "\n");

    System.out.println("Total # Searches = " + nb_of_searches + "\n");

    System.out.println("Successful Searches:");
    System.out.println("  Count = " + success.size());
    System.out.println("  Avg # Comparaisons = " + avg(success));
    if (tbl) print(success);
    System.out.println();

    System.out.println("Failed Searches:");
    System.out.println("  Count = " + failure.size());
    System.out.println("  Avg # Comparaisons = " + avg(failure));
    if (tbl) print(failure);
    System.out.println();
  }

  /**
   * Computes the avg of the values in the map
   * @param mp (key, value) pairs for which we want to compute the average
   * @return the average of the values in the map
   */
  public static double avg(Map<Long, Integer> mp){
    double x = 0;
    Iterator<Map.Entry<Long, Integer>> itr = mp.entrySet().iterator();
	  while (itr.hasNext()) {
	    Map.Entry<Long, Integer> e = itr.next();
	    x += e.getValue();
	  }
    return x / mp.size();
  }

  public static void main(String[] args) throws FileNotFoundException{
    read_file(new Scanner(new File("random_5000.txt")));
    FindAll(new Scanner(new File("test_data.txt")));

    PrintStream out_console = System.out;
    write_output(new PrintStream(new File("Ex1.txt")), true);
    write_output(out_console, false);
  }
}
