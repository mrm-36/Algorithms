import java.util.*;

/**
 * @author Miguel R. Merheb
 */

public class BST {
  private Node root = null; // pointer to the node of the root
  private int sz = 0; // nb of nodes in the tree

  public BST() {}

  public int size() {return sz;}
  public Node root() {return root;}

  public boolean isEmpty() {return sz == 0;}
  public int height() {return getHeight(root()) - 1;}

  //---------------- TREE EXTRA OPERATION ------------------//

  /**
   * return the node with the minimum value in the tree
   * i.e. the left-most node
   * @param curr node from where to start the search
   * @return the minimum node
   */
  public Node getMinNode(Node curr){
    while (curr != null && curr.getLeft() != null) curr = curr.getLeft();
    return curr;
  }

  /**
   * recursively computes the height of the tree
   * @param curr node from where to start the search
   * @return height of the tree
   */
  private int getHeight(Node curr){
    if (curr == null) return 0;
    return 1 + Math.max(getHeight(curr.getLeft()), getHeight(curr.getRight()));
  }

  //---------------- TREE OPERATION ------------------//

  /**
   * Adds a new node to the BST with value x
   * @param x value of the new node
   */
  public void add(long x){
    Node nw = new Node(x); ++sz;
    if (root == null) {root = nw; return;}
    Node curr = root;
    while (true){
      if (x < curr.getX()) {
        if (curr.getLeft() == null) {curr.setLeft(nw); return;}
        curr = curr.getLeft();
      }
      else {
        if (curr.getRight() == null) {curr.setRight(nw); return;}
        curr = curr.getRight();
      }
    }
  }

  /**
   * removes the first node that has the value x
   * @param x value of the node to remove
   * @return True if we found the node (removed it), and false otherwise
   */
  public boolean remove(long x){
    Node curr = root();
    while (curr != null && x != curr.getX()){
      if (x < curr.getX()) curr = curr.getLeft();
      else curr = curr.getRight();
    }
    if (curr == null) return false;
    if (curr.isLeaf()){
      Node parent = curr.getParent();
      if (parent == null) root = null;
      else {
        if (parent.getLeft() == curr) parent.setLeft(null);
        else parent.setRight(null);
      }
      --sz; return true;
    }
    if (curr.getRight() == null){
      Node parent = curr.getParent();
      if (parent == null) root = null;
      else {
        if (parent.getLeft() == curr) parent.setLeft(curr.getLeft());
        else parent.setRight(curr.getLeft());
      }
      --sz; return true;
    }
    if (curr.getLeft() == null){
      Node parent = curr.getParent();
      if (parent == null) root = null;
      else {
        if (parent.getLeft() == curr) parent.setLeft(curr.getRight());
        else parent.setRight(curr.getRight());
      }
      --sz; return true;
    }
    Node successor = getMinNode(curr.getRight());
    long k = successor.getX();
    remove(k);
    curr.setX(k);
    return true;
  }

  /**
   * searches for the first node with value x
   * @param x value of the node we are trying to find
   * @return TRUE if we found the node, and FALSE otherwise
   */
  public boolean find(long x){
    Node curr = root();
    while (curr != null && curr.getX() != x){
      if (x < curr.getX()) curr = curr.getLeft();
      else curr = curr.getRight();
    }
    return (curr != null && curr.getX() == x);
  }

  //---------------- TREE TRAVERSAL ------------------//

  /**
   * @return List of all the nodes in tree traversed In-Order
   */
  public List<Node> inOrder() {
    List<Node> v = new ArrayList<Node>();
    if (!isEmpty()) inOrder(root(), v);
    return v;
  }

  /**
   * Fills the list with the nodes of the tree in an In-Order manner
   * @param p current node
   * @param v list that we are filling
   */
  private void inOrder(Node p, List<Node> v){
    if (p.getLeft() != null) inOrder(p.getLeft(), v);
    v.add(p);
    if (p.getRight() != null) inOrder(p.getRight(), v);
  }

  /**
   * @return List of all the nodes in tree traversed Pre-Order
   */
  public List<Node> preOrder() {
    List<Node> v = new ArrayList<Node>();
    if (!isEmpty()) dfs(root(), v);
    return v;
  }

  /**
   * Fills the list with the nodes of the tree in an Pre-Order manner
   * @param p current node
   * @param v list that we are filling
   */
  private void dfs(Node p, List<Node> v){
    v.add(p);
    if (p.getLeft() != null) dfs(p.getLeft(), v);
    if (p.getRight() != null) dfs(p.getRight(), v);
  }

  /**
   * @return List of all the nodes in tree traversed Post-Order
   */
  public List<Node> postOrder() {
    List<Node> v = new ArrayList<Node>();
    if (!isEmpty()) postOrder(root(), v);
    return v;
  }

  /**
   * Fills the list with the nodes of the tree in an Post-Order manner
   * @param p current node
   * @param v list that we are filling
   */
  private void postOrder(Node p, List<Node> v){
    if (p.getLeft() != null) postOrder(p.getLeft(), v);
    if (p.getRight() != null) postOrder(p.getRight(), v);
    v.add(p);
  }

  /**
   * Traverses the tree from top to bottom, from left to right
   * @return List of the all the nodes in the above specified order
   */
  public List<Node> bfs() {
    List<Node> v = new ArrayList<Node>();
    if (isEmpty()) return v;
    Queue<Node> q = new LinkedList<>();
    q.add(root);
    while (!q.isEmpty()){
      Node temp = q.remove();
      if (temp.getLeft() != null) q.add(temp.getLeft());
      if (temp.getRight() != null) q.add(temp.getRight());
      v.add(temp);
    }
    return v;
  }

  /**
   * prints the nodes of the tree in a sideways manner
   */
  public void printSideways() {printSideways(root(), "");}
  /**
   * helper function to the above "printSideways" function
   * @param p current node
   * @param indent current indentation level
   */
  private void printSideways(Node p, String indent){
    if (p == null) return;
    printSideways(p.getRight(), indent + "  ");
    System.out.println(indent + p.getX());
    printSideways(p.getLeft(), indent + "  ");
  }
}