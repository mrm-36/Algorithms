public class Node {
  private int x;
  private int level;
  private Node left;
  private Node right;
  private Node parent;

  // ------------------ Constructors ------------------ //
  
  public Node(int _x, Node _parent, Node _left, Node _right) {
    x = _x; parent = _parent; left = _left; right = _right;
  }
  public Node(int _x) {this(_x, null, null, null);}
  public Node(int _x, Node p){
    this(_x, p, null, null);
    level = p.level + 1;
  }

  // ------------------ Getters and Setters ------------------ //
  public int getX() {return x;}
  public Node getParent() {return parent;}
  public Node getLeft() {return left;}
  public Node getRight() {return right;}
  public int getLevel() {return level;}
  
  public void setX(int _x) {x = _x;}
  public void setParent(Node _parent) {parent = _parent;}
  public void setLeft(Node _left) {left = _left;}
  public void setRight(Node _right) {right = _right;}
  public void setLevel(int l) {level = l;}

  // ------------------ Basic Functions ------------------ //

  public boolean isRoot() {return parent == null;}
  public int numChildren() {
    return (left != null ? 1 : 0) + (right != null ? 1 : 0);
  }
  public int subtreeSize() {
    return (1 + 
            (getLeft() != null ? getLeft().subtreeSize() : 0) +
            (getRight() != null ? getRight().subtreeSize() : 0));
  }
  public Node[] children(){
    Node[] x = {getLeft(), getRight()};
    return x;
  }
}