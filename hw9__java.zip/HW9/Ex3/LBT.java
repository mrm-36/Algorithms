import java.util.*;

/**
 * @author Miguel R. Merheb
 */

public class LBT {
  private Node root = null; //pointer to the root of the tree
  private int sz = 0; // nb of nodes in the tree

  // ------------------ Constructors ------------------ //
  public LBT() {}

  /**
   * Creates a new tree using the values in the list
   * @param lst list of values of the new nodes
   */
  public LBT(int[] lst){
    if (lst.length == 0) return;
    Queue<Node> q = new LinkedList<>();
    addRoot(lst[0]); q.add(root());
    for (int i = 1; i < lst.length; ++i){
      Node p = q.remove();
      q.add(addLeft(p, lst[i++]));
      if (i < lst.length) q.add(addRight(p, lst[i]));
    }
  }

  // ------------------ Basic Function ------------------ //
  public int size() {return sz;}
  public boolean isEmpty() {return sz == 0;}
  public Node root() {return root;}
  public int height() {return getHeight(root());}

  public void clear() {
    root = null; sz = 0;
  }

  // ------------------ Getters and Setters ------------------ //

  /**
   * Initializes the root of the tree
   * @param x the element stored in the new node
   * @return the new root
   * @throws IllegalStateException if the tree already has a root
   */
  public Node addRoot(int x) throws IllegalStateException {
    if (!isEmpty()) throw new IllegalStateException("Tree is not empty.");
    root = new Node(x); root.setLevel(1); sz = 1;
    return root;
  }

  /**
   * Adds a new node to the left of the parent p
   * @param p parent of the new node
   * @param x element stored in the new node
   * @return the new node that we created
   * @throws IllegalArgumentException if the parent is null, or already has a left child
   */
  public Node addLeft(Node p, int x) throws IllegalArgumentException {
    if (p == null) throw new IllegalArgumentException("Node is null.");
    if (p.getLeft() != null) throw new IllegalArgumentException("Node already has a left child.");
    Node child = new Node(x, p);
    p.setLeft(child); ++sz;
    return child;
  }

  /**
   * Adds a new node to the right of the parent p
   * @param p parent of the new node
   * @param x element stored in the new node
   * @return the new node that we created
   * @throws IllegalArgumentException if the parent is null, or already has a right child
   */
  public Node addRight(Node p, int x) throws IllegalArgumentException {
    if (p == null) throw new IllegalArgumentException("Node is null.");
    if (p.getRight() != null) throw new IllegalArgumentException("Node already has a right child.");
    Node child = new Node(x, p);
    p.setRight(child); ++sz;
    return child;
  }

  /**
   * Removes the node n and replaces it with one of it's children
   * @param n the node that needs to be removed
   * @throws IllegalArgumentException if the node is null or if it has 2 children
   */
  public void remove(Node n) throws IllegalArgumentException {
    if (n == null) throw new IllegalArgumentException("Node is null.");
    if (n.numChildren() == 2) throw new IllegalArgumentException("Node has 2 children.");
    Node c = (n.getLeft() != null ? n.getLeft() : n.getRight());
    if (c != null) c.setParent(n.getParent());
    if (n == root) root = c;
    else {
      Node p = n.getParent();
      if (n == p.getLeft()) p.setLeft(c);
      else p.setRight(c);
    }
    n.setLeft(null); n.setRight(null); n.setParent(null);
    --sz;
  }

  /**
   * Removes the node n with its sub-trees
   * @param n the node to be removed
   */
  public void sudoRemove(Node n) {
    Node p = n.getParent(); sz -= n.subtreeSize();
    if (p.getLeft() == n) p.setLeft(null);
    else p.setRight(null);
  }

  // ------------------ Tree Traversal ------------------ //

  /**
   * prints an indented version of all the nodes in the tree
   */
  public void printIndented() {
    dfs(root(), "", -1);
    System.out.println("----------");
  }

  // ------------------ Helper Functions ------------------ //

  /**
   * returns the height of the sub-tree starting at curr
   * @param curr the starting node
   * @return the height from curr
   */
  private int getHeight(Node curr){
    if (curr == null) return 0;
    return 1 + Math.max(getHeight(curr.getLeft()), getHeight(curr.getRight()));
  }

  /**
   * prints all the nodes in the tree in an indented manner
   * "lt_" means left child
   * "rt_" means right child
   * @param u current node
   * @param indent current indentation level
   * @param l 0 if u is a left child, and 1 if u is a right child
   */
  private void dfs(Node u, String indent, int l) {
    System.out.println(indent + (l == 0 ? "lt_" : (l == 1 ? "rt_" : "")) + u.getX());
    Node[] x = u.children();
    if (x[0] != null) dfs(x[0], indent + "| ", 0);
    if (x[1] != null) dfs(x[1], indent + "| ", 1);
  }

  /**
   * Helper function for the "limitPathSum" function
   * removes the node and its sub-trees if the sum of the path to the node exceeds mx
   * @param n current node
   * @param x current path sum
   * @param mx maximum allowed sum
   */
  private void dfs(Node n, int x, int mx){
    if (n.getX() + x > mx) {sudoRemove(n); return;}
    for (Node c : n.children()){
      if (c == null) continue;
      dfs(c, x + n.getX(), mx);
    }
  }

  // ------------------ Exercise 3 Function ------------------ //

  /**
   * prints thew node at level n
   * @param n the level for which we need to print the nodes
   * @throws IllegalArgumentException if level smaller than 1 or level greater than height of the tree
   */
  public void printLevel(int n) throws IllegalArgumentException {
    if (n < 1 || n > height()) throw new IllegalArgumentException("Level is not in the range of the Tree.");
    if (isEmpty()) return;
    Queue<Node> q = new LinkedList<>();
    q.add(root());
    while (!q.isEmpty()){
      Node temp = q.remove();
      if (temp.getLeft() != null) q.add(temp.getLeft());
      if (temp.getRight() != null) q.add(temp.getRight());
      if (temp.getLevel() == n) System.out.println(temp.getX());
    }
  }

  /**
   * Removes all nodes that has only 1 child
   */
  public void tighten() {
    if (isEmpty()) return;
    Queue<Node> q = new LinkedList<>(); q.add(root());
    while (!q.isEmpty()){
      Node temp = q.remove();
      if (temp.getLeft() != null) q.add(temp.getLeft());
      if (temp.getRight() != null) q.add(temp.getRight());
      if (temp.numChildren() == 1) remove(temp);
    }
  }

  /**
   * Limits all the paths sums to limit
   * @param limit the maximium allowed sum in any path of the tree
   */
  public void limitPathSum(int limit) {
    if (isEmpty()) return;
    dfs(root(), 0, limit);
  }
}
