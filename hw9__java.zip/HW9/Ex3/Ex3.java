import java.util.*;

public class Ex3 {
  public static LBT tree;

  /**
   * Creates a new tree (First tree in the PDF of HW9 Ex3)
   */
  public static void init1(){
    int[] nodes = {
          12,
        19, 93,
      11, 14
    };
    tree = new LBT(nodes);
    Node p = tree.root();
    tree.addLeft(p.getLeft().getRight(), 10);
    tree.addRight(p.getRight(), 15);
  }

  /**
   * Creates a new tree (Second tree in the PDF of HW9 Ex3)
   */
  public static void init2(){
    int[] nodes = {
          12,
        28, 19,
      94
    };
    tree = new LBT(nodes);
    Node p = tree.root().getLeft().getLeft();
    tree.addLeft(p, 65); 
    p = tree.addRight(p, -8); tree.addRight(p, 10);
    p = tree.root().getRight();
    p = tree.addLeft(p, 32); p = tree.addRight(p, 72);
    tree.addLeft(p, 42); tree.addRight(p, 50);
  }

  /**
   * Creates a new tree (Third tree in the PDF of HW9 Ex3)
   */
  public static void init3(){
    int[] nodes = {
              29,
            17, 15,
        -7, 37, 4, 14,
      11, 12
    };
    tree = new LBT(nodes);
    Node p = tree.root();
    Node temp = p.getLeft().getRight(); tree.addRight(temp, 16);
    temp = p.getRight().getRight();
    tree.addLeft(temp, -9); tree.addRight(temp, 19);
  }

  public static void main(String[] args){
    init1(); 
    System.out.println("TREE 1");
    tree.printIndented();
    System.out.println("Nodes on Level 3");
    tree.printLevel(3);
    System.out.println("\n");

    init2(); 
    System.out.println("TREE 2");
    System.out.println("Before tighten()");
    tree.printIndented(); tree.tighten();
    System.out.println("After tighten()");
    tree.printIndented();
    System.out.println("\n");

    System.out.println("TREE 3");
    init3(); tree.printIndented();
    System.out.println("After limitPathSum(50)");
    tree.limitPathSum(50); tree.printIndented();
    System.out.println();
  }
}
